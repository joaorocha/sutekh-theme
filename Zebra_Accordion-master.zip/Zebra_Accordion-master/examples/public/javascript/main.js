$(document).ready(function() {

    new $.Zebra_Accordion('#Zebra_Accordion1');

    new $.Zebra_Accordion('#Zebra_Accordion2', {
        'collapsible':  true
    });

});